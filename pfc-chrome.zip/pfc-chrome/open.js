importScripts('reader.js')
chrome.action.onClicked.addListener(async tab => {
  const saved = await chrome.storage.local.get('website')
  const url = tab.url && new URL(tab.url)
  if (url?.protocol === 'https:' && url.hostname.endsWith('.github.io')) {
    const [page] = await chrome.scripting.executeScript({
      target: {tabId: tab.id},
      func: () => Boolean(document.querySelector('#connect #pair') && document.querySelector('#connect #key'))
    })
    if (page.result) {
      await chrome.scripting.executeScript({target: {tabId: tab.id}, files: ['pair.js']})
      await chrome.storage.local.set({website: url.origin + url.pathname})
      return
    }
  }
  if (saved.website) await chrome.tabs.create({url: saved.website})
})
async function api(config,fields){
  const response=await fetch(config.url,{method:'POST',body:JSON.stringify({...fields,warehouse:'399276',key:config.key}),signal:AbortSignal.timeout(25000)})
  if(!response.ok)throw Error('Google Таблица временно недоступна')
  return response.json()
}
async function processQueue(){
  return navigator.locks.request('pfc-agent',{ifAvailable:true},async lock=>{
    if(!lock)return
    const config=await chrome.storage.local.get(['url','key'])
    if(!config.key||!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(config.url))return
    const old=await chrome.storage.session.get('workingTab')
    if(old.workingTab){
      const previous=await chrome.tabs.get(old.workingTab).catch(()=>null)
      if(previous?.url?.startsWith('https://my-pfc.wb.ru/search'))await chrome.tabs.remove(previous.id)
      await chrome.storage.session.remove('workingTab')
    }
    for(let i=0;i<10;i++){
      const job=await api(config,{action:'poll'})
      if(!job.token)return
      let rows
      try{
        const workerWindow=await chrome.windows.create({url:'https://my-pfc.wb.ru/search',focused:false,state:'normal',type:'normal'})
        wb=workerWindow.tabs?.[0]?.id ?? (await chrome.tabs.query({windowId:workerWindow.id}))[0].id
        await chrome.storage.session.set({workingTab:wb})
        let ready=false
        for(let n=0;n<40;n++){
          await pause(500)
          const current=await chrome.tabs.get(wb)
          if(current.status==='complete' && current.url?.startsWith('https://my-pfc.wb.ru/search') &&
            await run(()=>Array.from(document.querySelectorAll('input')).some(el=>['text','search'].includes(el.type)&&el.offsetWidth))){ready=true;break}
        }
        if(!ready)throw Error('Поиск WB недоступен. Проверьте вход в складском профиле Chrome.')
        const error=await run(searchCell,job.cell,'399276')
        if(error)throw Error(error)
        const found=await collectCell(job.cell,'399276')
        const stamp=new Date().toISOString()
        rows=found.map(row=>[...row,stamp])
      }catch(e){
        await api(config,{...job,action:'fail',error:e.message})
        return
      }finally{
        if(wb!=null){
          await chrome.tabs.remove(wb).catch(()=>{})
          await chrome.storage.session.remove('workingTab')
          wb=null
        }
      }
      await api(config,{...job,action:'finish',rows})
    }
  })
}
function schedule(){chrome.alarms.create('pfc-queue',{periodInMinutes:0.5})}
chrome.runtime.onInstalled.addListener(schedule)
chrome.runtime.onStartup.addListener(schedule)
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='pfc-queue')processQueue().catch(console.error)})
chrome.runtime.onMessage.addListener(m=>{if(m.wake){schedule();processQueue().catch(console.error)}})
