(()=>{
if (document.documentElement.dataset.pfcAgent !== '3') {
document.documentElement.dataset.pfcAgent='3'
document.addEventListener('pfc-enable',async()=>{
  const url=document.getElementById('url')?.value.trim(),key=document.getElementById('key')?.value
  if(!key||!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(url))return
  await chrome.storage.local.set({url,key})
  chrome.runtime.sendMessage({wake:true}).catch(()=>{})
  document.dispatchEvent(new Event('pfc-enabled'))
})
}
const openConnection = document.querySelector('dialog')
if (!openConnection.open) openConnection.showModal()
document.getElementById('pair').hidden = false

})();