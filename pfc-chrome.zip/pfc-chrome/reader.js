let wb
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms))
async function run(fn,...args){
  const [frame]=await chrome.scripting.executeScript({target:{tabId:wb},func:fn,args})
  return frame.result
}
async function searchCell(cell,warehouse){
  if(location.pathname!='/search') return 'Откройте раздел «Поиск» в кабинете WB.'
  if(!document.body.innerText.split(/\s+/).includes(warehouse)) return 'Выберите нужный номер ПФЦ в кабинете WB.'
  const fields=[...document.querySelectorAll('input')].filter(el=>['text','search'].includes(el.type)&&el.offsetWidth)
  if(fields.length!==1) return 'Не удалось определить поле поиска. Выберите режим «По МХ».'
  const input=fields[0]
  globalThis.pfcEmptyCheck={cell,warehouse,fresh:!document.body.innerText.includes('По вашему запросу ничего не найдено')}
  input.focus()
  Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,cell)
  input.dispatchEvent(new Event('input',{bubbles:true}))
  input.dispatchEvent(new Event('change',{bubbles:true}))
  await new Promise(resolve=>setTimeout(resolve,350))
  let wrapper=input.parentElement,button
  for(let depth=0;wrapper && depth<4;depth++,wrapper=wrapper.parentElement){
    if(wrapper.querySelectorAll('input').length!==1) break
    const buttons=[...wrapper.querySelectorAll('button,[role="button"],[aria-label]')].filter(el=>el!==input && el.offsetWidth && !el.disabled)
    button=buttons.find(el=>/поиск|найти|search/i.test([el.title,el.ariaLabel,el.textContent].join(' ')))
    if(button) break
  }
  if(button) button.click()
  else {
    for(const type of ['keydown','keypress','keyup']) input.dispatchEvent(new KeyboardEvent(type,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}))
    if(input.form) input.form.requestSubmit()
  }
  return ''
}
function readResult(cell,warehouse){
  const lines=document.body.innerText.replace(/\s+/g,' ').trim()
  if(!lines.split(' ').includes(warehouse)) return {reason:'Номер ПФЦ отсутствует на странице WB.'}
  const heading=/(?:^|\s)МХ\s*(\d{2}\.\d{2}\.\d{2})\s*[·•●|—–-]?\s*(\d+)\s*БК(?![А-Яа-я])/i.exec(lines)
  const state=globalThis.pfcEmptyCheck
  const empty=lines.includes('По вашему запросу ничего не найдено')
  if(state?.cell===cell && !empty) state.fresh=true
  if(!heading && empty && state?.fresh && state.cell===cell && state.warehouse===warehouse){
    const fields=[...document.querySelectorAll('input')].filter(el=>['text','search'].includes(el.type)&&el.offsetWidth)
    const selected=document.querySelector('input[type=radio]:checked,[role=radio][aria-checked=true]')
    const mode=selected?.labels?.[0]?.innerText || selected?.closest('label')?.innerText || selected?.parentElement?.innerText || ''
    if(fields.length===1 && fields[0].value===cell && /^По МХ$/i.test(mode.trim()) && !/Посмотреть на сайте/i.test(lines))
      return {rows:[],total:0}
    return {reason:'WB сообщает о пустом результате. Проверьте адрес и режим «По МХ».'}
  }
  if(!heading) return {reason:'В ответе WB не найден заголовок с адресом и числом БК.'}
  if(heading[1]!==cell) return {reason:'WB показывает адрес '+heading[1]+'.'}
  const cards=lines.slice(heading.index+heading[0].length).split(/(?:^|\s)БК\s*[:№]?\s*([A-Za-z0-9][A-Za-z0-9_-]*)(?=\s+\d+\s*шт)/i)
  const rows=[]
  for(let i=1;i<cards.length;i+=2){
    const m=/^\s*(\d+)\s*шт\.?\s+(.+?)\s+Посмотреть на сайте/i.exec(cards[i+1])
    if(!m) return {reason:'WB показал адрес, но количество или название в карточке не распознано.'}
    rows.push([cell,cards[i],m[2].trim(),Number(m[1])])
  }
  return {rows,total:Number(heading[2])}
}

function advanceResults(pageNumber,allowClick){
  const visible=el=>el.getClientRects().length>0
  const links=[...document.querySelectorAll('a,button,span,div')].filter(el=>
    el.childElementCount===0 && /Посмотреть\s+на\s+сайте/i.test(el.textContent) && visible(el))
  const last=links.at(-1)
  if(last)last.scrollIntoView({block:'end',behavior:'instant'})
  const containers=new Set([document.scrollingElement])
  for(let parent=last?.parentElement;parent;parent=parent.parentElement){
    if(parent.scrollHeight>parent.clientHeight+2)containers.add(parent)
  }
  for(const container of containers){
    if(container)container.scrollTop=container.scrollHeight
  }
  if(!allowClick) return false
  const controls=[...document.querySelectorAll('button,a,[role=button]')].filter(el=>
    !last || (last.compareDocumentPosition(el)&Node.DOCUMENT_POSITION_FOLLOWING))
  const target=controls.find(el=>{
    if(!el.getClientRects().length||el.disabled||el.getAttribute('aria-disabled')==='true') return false
    const names=[el.textContent,el.getAttribute('aria-label'),el.title].filter(Boolean).map(x=>x.trim())
    return names.some(x=>/^(показать ещ[её](?: \d+)?|загрузить ещ[её]|следующая(?: страница)?|впер[её]д|next(?: page)?)$/i.test(x)) ||
      (el.closest('nav,[class*="pagin" i],[aria-label*="страниц" i]') && names.includes(String(pageNumber)))
  })
  if(target){target.click();return true}
  return false
}

async function collectCell(cell,warehouse){
  const seen=new Map()
  let total,previous,reason='Ожидание ответа WB.',pageNumber=2,lastClick=0
  let deadline=Date.now()+30000
  const limit=Date.now()+240000
  while(Date.now()<Math.min(limit,deadline)){
    await pause(650)
    const part=await run(readResult,cell,warehouse)
    if(part.reason){
      previous=undefined
      // WB can briefly replace the list with a loading indicator between pages.
      reason=part.reason
      continue
    }
    if(total!==undefined && total!==part.total) throw Error('Состав ячейки изменился во время проверки. Повторите поиск.')
    total=part.total
    const size=seen.size
    for(const row of part.rows){
      const old=seen.get(row[1])
      if(old&&(old[2]!==row[2]||old[3]!==row[3])) throw Error('Данные карточки изменились. Повторите поиск.')
      seen.set(row[1],row)
    }
    if(seen.size>total) throw Error('Карточек больше, чем указано WB. Повторите поиск.')
    if(seen.size===total){
      const signature=JSON.stringify(part.rows)
      if(previous===signature) return total?[...seen.values()]:[[cell,'','Пустая ячейка',0]]
      previous=signature
      continue
    }
    if(seen.size>size) deadline=Date.now()+30000
    reason='Собрано '+seen.size+' из '+total+' БК.'
    // Partial results remain local until the entire cell is confirmed.
    if(await run(advanceResults,pageNumber,Date.now()-lastClick>3500)){
      lastClick=Date.now()
      pageNumber++
    }
  }
  throw Error('МХ '+cell+'. '+reason)
}
